# Offline Shop — Android POS & Inventory App

A fully offline shop app built with **Kotlin + Jetpack Compose + Room**. All data
(products, sales, sale line-items) is stored locally in an SQLite database via Room,
so the app works with **no internet connection required**.

## Features

- **Inventory management** (Inventory tab)
  - Add, edit, and delete products (name, SKU, price, stock quantity)
  - Low-stock items (≤5 units) are flagged in red automatically
- **Sell / Point of Sale** (Sell tab)
  - Tap +/− to build a cart from your product list
  - Live running total and item count
  - "Complete Sale" records the transaction and **automatically deducts stock**,
    all inside a single atomic database transaction so inventory can never
    drift out of sync with sales
- **Sales history** (History tab)
  - Every past sale with date/time and total
  - Tap a sale to expand and see the individual line items

## Project structure

```
app/src/main/java/com/example/offlineshop/
├── MainActivity.kt              # Bottom nav + Compose entry point
├── data/
│   ├── Product.kt                # Room entity
│   ├── Sale.kt                   # Room entity
│   ├── SaleItem.kt                # Room entity (line items)
│   ├── ProductDao.kt
│   ├── SaleDao.kt
│   ├── AppDatabase.kt            # Room database singleton
│   └── InventoryRepository.kt    # Checkout transaction logic
└── ui/
    ├── InventoryViewModel.kt     # Shared state for all screens
    ├── InventoryScreen.kt
    ├── SellScreen.kt
    └── SalesHistoryScreen.kt
```

## How to open and run

1. Open **Android Studio** (Hedgehog or newer recommended).
2. Choose **File → Open**, and select the `OfflineShopApp` folder.
3. Let Gradle sync (it will download the AndroidX, Compose, and Room dependencies —
   this step needs internet once; the app itself runs fully offline after that).
4. Click **Run ▶** on an emulator or physical device (minimum Android 7.0 / API 24).

## Extending it further

Some natural next steps if you want to keep building:
- Add barcode scanning (e.g. with CameraX + ML Kit) to speed up the Sell screen
- Add categories/tags to products and filter/search in Inventory
- Export sales history to CSV for accounting
- Add a "restock" quick-action button on low-stock items
- Add user accounts / PIN lock if multiple staff use the same device
